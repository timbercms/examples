<div class="example-content">
    <?php echo $worker->module->params->content; ?>
</div>